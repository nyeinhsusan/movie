import React, { Component } from 'react'
import HeaderComponent from './component/HeaderComponent'
import FooterComponent from './component/FooterComponent'
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import HomeComponent from './component/HomeComponent';
import AboutUsComponent from './component/AboutUsComponent';
import DonateComponent from './component/DonateComponent';
import Register from './Signup/Register';
import ContactUsComponent from './component/ContactUsComponent';
import GetMeal from './Meal/GetMeal';
import OrderMeal from './Meal/OrderMeal';
// import LoginComponent from './user/login/Login';
export class App extends Component {
  render() {
    return (
      <div>
        <Router>
          <HeaderComponent></HeaderComponent>
          
           <Switch>
              <Route exact path="/" component={HomeComponent}></Route>
            <Route path="/about" component={AboutUsComponent}></Route>
             <Route path="/contact" component={ContactUsComponent}></Route>
            <Route path="/donate" component={DonateComponent}></Route>
            <Route path="/register" component={Register}></Route>
            <Route path="/getmeal" component={GetMeal}></Route>
                <Route path="/ordermeal" component={OrderMeal}></Route>
           </Switch>
        
          <FooterComponent></FooterComponent>
        </Router>
      </div>
    )
  }
}

export default App