import React, { Component } from 'react'
import Form from 'react-bootstrap/Form';
import { Link } from 'react-router-dom';
export class Login extends Component {
  render() {
    return (
  
    )
  }
}

export default Login
