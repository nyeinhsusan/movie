import React, { Component } from 'react'
import img4 from '../images/get-involve.jpg'
export class GetMeal extends Component {
  render() {
    return (
      <div>
        {/* Cover section  start */}
		<div class="card text-bg-dark">
 				 <img src={img4} class="card-img" alt="..."/>
			<div class="card-img-overlay">
					<div class="card-body">
							<h5 class="card-title text-start ">Hello </h5>
							<span>Welcome to </span>
    				<p class="card-text">The Meal and Wheel family</p>
    					<a href="#" class="btn btn-info ">Donate Now</a>
  				</div>
			</div> 
		</div>	
				
				{/* cover section end  */}
      </div>
    )
  }
}

export default GetMeal
