import React, { Component } from 'react'
import { Link } from 'react-router-dom/cjs/react-router-dom.min'
export class DonateComponent extends Component {
  render() {
    return (
      <div>
        <h1>Donate page</h1>
      </div>
    )
  }
}

export default DonateComponent


 

